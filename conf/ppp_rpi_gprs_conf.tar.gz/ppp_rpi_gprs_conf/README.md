# Raspberry Pi PPP GPRS Configuration

This directory contains production-ready PPP configuration for Raspberry Pi with a GPRS modem.

## File structure

- **/etc/ppp/options**: Global PPP options
- **/etc/ppp/peers/gprs**: Peer-specific configuration (device, speed, connect, routing)
- **/etc/ppp/peers/chat-connect**: Chat script for connecting to APN
- **/etc/ppp/peers/chat-disconnect**: Chat script for disconnect
- **/etc/ppp/ip-up.d/1nce-routing**: Script to add selective 1NCE routes on PPP up
- **/etc/ppp/ip-down.d/1nce-routing-cleanup**: Script to cleanup routes and rules on PPP down

## Usage

1. Place files in their respective directories on the Raspberry Pi.
2. Make sure scripts in ip-up.d and ip-down.d are executable.
3. Adjust APN in chat-connect as needed.
4. Restart PPP service: `sudo systemctl restart pppd@gprs`
5. Verify PPP interface and routes:
   ```bash
   ip a show ppp0
   ip route show dev ppp0
   ```
